//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CrashMe.rc
//
#define IDR_MAINFRAME                   101
#define IDD_ERAS_ME_DIALOG              102

#define IDC_BTN_BREAKPOINT              105
#define IDC_BTN_INT3                    106
#define IDC_BTN_RAISE_EXCPT             107
#define IDC_BTN_THROW_CPP               108
#define IDC_BTN_STACK_OVERFLOW          109
#define IDC_BTN_STACK_OVERFLOW_RECURSION 110
#define IDC_BTN_DIV_BY_NULL             111
#define IDC_BTN_NESTED_EXCEPTIONS       112

#define IDC_BTN_ACCESS_TEST_VARIABLE    113
#define IDC_BTN_CHECK_FOR_DEBUGGER      114
#define IDC_BTN_ENTER_CS                115
#define IDC_BTN_CALLING_CONVENTION      116
#define IDC_BTN_INVALID_HANDLE          117
#define IDC_BTN_SETLAST_ERROR           118

#define IDC_BTN_HEAPALLOC               119
#define IDC_BTN_HEAPDEALLOC             120
#define IDC_BTN_OPERATOR_NEW            121
#define IDC_BTN_OPERATOR_DELETE         122
#define IDC_BTN_HEAP_CREATE             123
#define IDC_BTN_HEAP_DESTROY            124
#define IDC_BTN_MEMORY_LEAK             125

#define IDC_BTN_LOAD_DLL                126
#define IDC_BTN_UNLOAD_DLL              127
#define IDC_BTN_CREATE_THREAD           128
#define IDC_BTN_END_THREAD              129
#define IDC_BTN_TEST_ARRAYS             130

#define IDC_BTN_DUMP_ME_ON_EXCEPTION    131
#define IDC_BTN_REPORT_FAULT            132
#define IDC_CHK_OVERRIDE_UHANDLED_EXCP_FILTER 133
#define IDC_CHK_DEBUG_BREAK_ON_ACTION   134


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
