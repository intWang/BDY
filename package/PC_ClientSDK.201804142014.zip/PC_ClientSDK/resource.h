//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PPCS_ClientUI.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PPCS_CLIENTUI_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_APIVER                      1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT_DEV_NAME_OSD_X         1003
#define IDC_LOGIN                       1004
#define IDC_START                       1005
#define IDC_STOP                        1006
#define IDC_AVINFO                      1007
#define IDC_LOGOUT                      1008
#define IDC_VIDEO                       1009
#define IDC_CHECK1                      1010
#define IDC_CHECK2                      1011
#define IDC_STATIC_STATUS               1012
#define IDC_BUTTON1                     1013
#define IDC_BUTTON2                     1014
#define IDC_CHECK3                      1015
#define IDC_BUTTON3                     1016
#define IDC_BUTTON4                     1017
#define IDC_CHECK4                      1018
#define IDC_BUTTON5                     1019
#define IDC_BUTTON6                     1020
#define IDC_BUTTON7                     1021
#define IDC_BUTTON8                     1022
#define IDC_BUTTON9                     1023
#define IDC_BUTTON10                    1024
#define IDC_BUTTON11                    1025
#define IDC_BUTTON12                    1026
#define IDC_BUTTON13                    1027
#define IDC_BUTTON14                    1028
#define IDC_BUTTON15                    1029
#define IDC_BUTTON_GET_OSD              1030
#define IDC_BUTTON_SET_OSD              1031
#define IDC_BUTTON_GET_ALARM            1032
#define IDC_BUTTON_SET_ALARM            1033
#define IDC_CHECK_DEV_NAME              1034
#define IDC_EDIT_DEV_NAME_OSD_Y         1036
#define IDC_CHECK_ENABLE_ALARM          1037
#define IDC_CHECK_ALARM_RECORD          1038
#define IDC_CHECK9                      1039
#define IDC_CHECK_ALARM_SNAPSHOT        1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
